## Project setup
```
npm install
```

### Run
```
node server.js
```

### Run
```
access api's by <ip>/api/products
```
